package wenhanfa_CSCI201L_Assignment1;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;
import java.util.Arrays;
import java.util.Collections;

public class test {
	static String cat [] = new String [5];
	static int value [] = new int [5];
	static String question [] = new String [26];
	static String answer [] = new String [26];
	//return 1 if there is format error
public static int readFile(String fileName){
	FileReader fr = null;
	BufferedReader br = null;
	int questionNum = 0;
	try{
		cat[0]="";
		cat[1]="";
		cat[2]="";
		cat[3]="";
		cat[4]="";
		fr = new FileReader(fileName);
		br = new BufferedReader(fr);
		
		//1. first line
		String line = br.readLine();
		line = line.toLowerCase();
		int j = 0;
		int flipper = 0;
		for(int i=0;i<line.length();i++){
			if(Character.isLetter(line.charAt(i))){	//if character
				if(flipper == 1){
					System.out.println("Format error");
					return 1;	//if only one : exist, return error
				}
				cat[j] = cat[j] +line.charAt(i);
			}
			else if(line.charAt(i)==':'){ //if :
				if(flipper == 0){	//if no : in front of this :
					flipper = 1;
				}
				else {
					j++;
					flipper = 0;
				}	
			}
			else{
				System.out.println("Format error");		//if neither letter nor :
				return 1;
			}
		}
		if(j != 4){
			System.out.println("Only 5 catagories allowed");
			return 1;
		}
		for(int i = 0;i<3;i++){
			for(int k = i+1; k < 5; k++)
			if(cat[i] == cat[k]){
				System.out.println("Duplicate catagory");
				return 1;
			}
		}

		
		//2. second line
		value [0] = 0;
		value [1] = 0;
		value [2] = 0;
		value [3] = 0;
		value [4] = 0;
			
		line = br.readLine();
		line = line.toLowerCase();
		j = 0;
		flipper = 0;
		for(int i=0;i<line.length();i++){
			if(Character.isDigit(line.charAt(i))){	//if digit
				if(flipper == 1){
					System.out.println("Format error");
					return 1;	//if only one : exist, return error
				}
				value[j] = value[j]*10 +line.charAt(i)-48;
			}
			else if(line.charAt(i)==':'){ //if :
				if(flipper == 0){	//if no : in front of this :
					flipper = 1;
				}
				else {
					j++;
					flipper = 0;
				}	
			}
			else{	//if neither number nor :
				System.out.println("Format error");
				return 1;
			}
		}
		if(j != 4){
			System.out.println("Only 5 values allowed");
			return 1;
		}
		for(int i = 0;i<3;i++){
			for(int k = i+1; k < 5; k++)
			if(value[i] == value[k]){
				System.out.println("Duplicate values");
				return 1;
			}
		}

		
		
		//3. normal questions line
		for(int i = 0; i< 26; i++){
			question[i] = "";
			answer[i] = "";
		}
		line = br.readLine();
		line = line.toLowerCase();		//first line of question must start from ::
		if(line.charAt(0)!=':'|| line.charAt(1)!=':'){
			System.out.println("Format error: first line didn't start with ::");
			return 1;
		}

		int CoCounter = 0;	//count how many : in this line
		int CaCounter = 0;		//count which category is the line
		int VaCounter = 0;		//count which value is the current one
		String CatTemp = "";	//save the category name temporarily
		int jp = 0;
		int ValTemp = 0;
		for(int i = 0; i< 26; i++)
		{
			for(int q=0;q<line.length();q++){
				//update CoCounter when a new :: appeared
				if(line.charAt(q) == ':'&& line.charAt(q+1) ==':'){
						CoCounter++;
						q++;
						continue;
				}
				
				
				//Final Jeopardy
				if(q ==2){
					if(line.charAt(q) == 'f' && line.charAt(q+1) == 'j'){
						q++;
						jp ++;
						if(jp == 3){
							System.out.println("too many lines of jp");
							return 1;
						}
						continue;
					}	
				}

				
				
				//loading fj
				if(jp!=0){
					if(CoCounter == 2){
						question[25]+= line.charAt(q);
					}
					else if(CoCounter == 3){
						answer[25]+= line.charAt(q);
					}
					else{
						System.out.println("Wrong number of :: in FJ");
						return 1;
					}
					continue;
				}
				
				
				//if only one colon pair appeared
				if(CoCounter ==1){	
					CatTemp += line.charAt(q);
					if(line.charAt(q+1) == ':' && line.charAt(q+2) == ':'){
						for(int m = 0; m < 5; m++){
							if(CatTemp.equals(cat[m])){		//why not ==?
								CaCounter = m;
								break;
							}
							if(m == 4){
								System.out.println(CatTemp);
								System.out.println("Category name in question cannot be found");
								return 1;
							}
						}
					}
				}
				
				
				//if two colon pair already
				else if(CoCounter == 2){
					if(Character.isDigit(line.charAt(q)))	//must be digit
					{
						ValTemp = 10*ValTemp + line.charAt(q) - 48;
						if(line.charAt(q+1) == ':' && line.charAt(q+2) == ':'){
							for(int m = 0; m < 5; m++){
								if(ValTemp == value[m]){
									VaCounter = m;
									break;
								}
								if(m == 4){
									System.out.println("Value in question cannot be found");
									return 1;
								}
							}
						}
					}
					else{
						System.out.println("Value in question is not a digit");
						return 1;
					}
				}
				
				//if three colon pair already
				else if (CoCounter == 3){
					question[CaCounter*5+VaCounter]+= line.charAt(q);
				}
				
				//if four colon pair already
				else if (CoCounter == 4){
					answer[CaCounter*5+VaCounter]+= line.charAt(q);
				}
				
			}

			if((line=br.readLine())!=null){
				line = line.toLowerCase();
				if(i == 25 && line.charAt(0)==':' && line.charAt(1)==':'){
					System.out.println("The number of questions more than 26");
					return 1;
				}
			}
			else{	//if less than 26 statements
				if(i != 25){
					System.out.println("The number of questions is less than 26");
					return 1;
				}
				else{
					continue;
				}
			}
			if(line.charAt(0)==':' && line.charAt(1)==':')	//reset the indexes if the line really ends
			{
				if(jp!=1 && CoCounter!=4){	//check if exactly 4 ::
					System.out.println("The number of :: is not 4");
					return 1;
				}
				if(jp == 1){
					if(CoCounter !=3){
						System.out.println("The number of :: is not 3 in jp line");
						return 1;
					}
					jp =2;
				}
				CoCounter = 0;	//count how many : in this line
				CaCounter = 0;		//count which category is the line
				VaCounter = 0;		//count which value is the current one
				CatTemp = "";	//save the category name temporarily
				ValTemp = 0;
			}
			else{	//else don't change the index
				i--;
			}
		}
		for(int i=0;i<26;i++){
			System.out.println(question[i]);
		}
		
		//4. Final Jeopardy
		
	}catch(FileNotFoundException fnfe){
		System.out.println(fnfe.getMessage());
	}catch(IOException ioe){
		System.out.println(ioe.getMessage());
	}finally{
		if(br != null){
			try{
				br.close();
			}catch (IOException ioe){
				System.out.print(ioe.getMessage());
			}
		}
		
	}
		

	return 0;	
}

//main function
public static void main(String [] Argv)
{
	String fileName = Argv[0];
	String tempCat = "";
	String tempAns = "";
	boolean [] qsUsed = new boolean [25];
	int tempVal =0;
	boolean passCat = false;
	boolean passVal = false;
	int flag = readFile(fileName);
	int catNum = 0;
	int valNum = 0;
	boolean usedAgain = false;
	int triedNum = 0;
	
	if(flag == 1){
		System.out.println("System terminated");
		return;
	}
	InputStreamReader isr = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);
	boolean Team = true;
	int TeamNum = 0;
	try{
		
		while(Team){
			System.out.print("how many teams do u want (1-4): ");
			String Line = br.readLine();
			TeamNum = Integer.parseInt(Line);
			if(TeamNum < 1 || TeamNum > 4)
			{
				System.out.println("Team number can be only from 1 to 4");
			}
			else{
				Team = false;
			}
		}
		String Names [] = new String [TeamNum];
		int [] score = new int [TeamNum];
		for(int i=1;i<=TeamNum;i++){
			System.out.println("Please choose a name for team "+i);
			Names[i-1] = br.readLine();
		}
		Random 	rn = new Random();
		int start = rn.nextInt(TeamNum)+1;
		int NumOfQsUsed = 0;
		
		while(NumOfQsUsed!=25)
		{
			System.out.println("Turn for "+ Names[start]);
			do{
				while(!passCat){
					System.out.print("Choose a category:");
					tempCat = br.readLine();
					tempCat = tempCat.toLowerCase();
					for(int i = 0; i < 5; i++){
						if(tempCat.equals(cat[i]) ){
							catNum = i;
							passCat = true;
						}
					}	
				}
				
				while(!passVal){
					System.out.print("Choose a value:");
					tempVal = Integer.parseInt(br.readLine());
					for(int i = 0; i < 5; i++){
						if(tempVal == value[i]){
							valNum = i;
							passVal = true;
						}
					}
				}
				if(qsUsed[5*catNum+valNum]){
					System.out.print("question used already, choose another one");
					usedAgain = true;
					passCat = false;
					passVal = false;
				}
				else{
					usedAgain = false;
				}
			}while(usedAgain);
			
			//asking question
			while(triedNum!=2){
				System.out.println(question[5*catNum+valNum]);
				System.out.println("Anwer:");
				tempAns = br.readLine();
				tempAns = tempAns.toLowerCase();
				if(tempAns.equals(answer[5*catNum+valNum])){
					System.out.println("Question format! Try again");
					triedNum++;
					if(triedNum == 2){
						System.out.println("Second times already!");
						score[start]-=value[valNum];
						NumOfQsUsed++;
						passVal = false;
						passCat = false;
						qsUsed[5*catNum+valNum] = true;
					}
					continue;
				}
				if (tempAns.equals("what is " + answer[5*catNum+valNum])||tempAns.equals("what are " + answer[5*catNum+valNum])
						||tempAns.equals("what is the " + answer[5*catNum+valNum]) || tempAns.equals("what are the " + answer[5*catNum+valNum])
						||tempAns.equals("who is " + answer[5*catNum+valNum]) || tempAns.equals("who are " + answer[5*catNum+valNum])
						||tempAns.equals("who is the " + answer[5*catNum+valNum])||tempAns.equals("who are the " + answer[5*catNum+valNum])){
					System.out.println("right answer!");
					score[start]+=value[valNum];
					NumOfQsUsed++;
					passVal = false;
					passCat = false;
					qsUsed[5*catNum+valNum] = true;
					break;
				}
				else{
					System.out.println("wrong answer!");
					score[start]-=value[valNum];
					NumOfQsUsed++;
					passVal = false;
					passCat = false;
					qsUsed[5*catNum+valNum] = true;
					break;
				}
			}
			start++;
			if(start == TeamNum){
				start = 0;
			}
		}
		
		//jp starts here
		String [] jpAns = new String [TeamNum];
		
		for(int i = 0; i < TeamNum; i++){
			System.out.print(Names[i] + ": " +score[i]);
			jpAns[i] = "";
		}
		
		int bet [] = new int [TeamNum];
		for(int i = 0; i < TeamNum; i++){
			System.out.print("Pay your bet" + Names[i]);
			bet[i] =Integer.parseInt(br.readLine());
			if(score[i]<0 && bet[i] != 0)
			{
				System.out.print("invalid bet, pay again, only 0 available for you");
				i--;
			}
			if(bet[i] <0 || bet[i] > score[i]){
				System.out.print("invalid bet, pay again");
				i--;
			}
		}
		System.out.print(question[25]);
		for(int i = 0; i < TeamNum; i++){
			System.out.print("Your answer" + Names[i]);
			jpAns[i] = br.readLine();
		}
		for(int i = 0; i < TeamNum; i++){
			if (jpAns[i].equals("what is " + answer[25])||jpAns[i].equals("what are " + answer[25])
					||jpAns[i].equals("what is the " + answer[25]) || jpAns[i].equals("what are the " + answer[25])
					||jpAns[i].equals("who is " + answer[25]) || jpAns[i].equals("who are " + answer[25])
					||jpAns[i].equals("who is the " + answer[25])||jpAns[i].equals("who are the " + answer[25])){
				score[i]+=bet[i];
			}
			else{
				score[i]-=bet[i];
			}
		}
		

		
	}catch(IOException ioe){
		System.out.println(ioe.getMessage());
	}

}
}
